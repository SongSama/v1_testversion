var searchData=
[
  ['numfingers',['numFingers',['../classkinova_1_1_kinova_comm.html#aec62e7da487b49e0a6351fcb9f226bde',1,'kinova::KinovaComm']]]
];
