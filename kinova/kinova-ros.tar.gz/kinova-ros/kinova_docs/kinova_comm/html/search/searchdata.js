var indexSectionsWithContent =
{
  0: "cefghiknprs",
  1: "fk",
  2: "k",
  3: "ceghiknprs",
  4: "k"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Pages"
};

